natded
======

A LaTeX package for natural deduction proofs in styles used by Jaśkowski and Kalish and Montague.

Package version: 0.1